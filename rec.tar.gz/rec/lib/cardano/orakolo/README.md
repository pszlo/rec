# orakolo
Some algorithms code reference

From https://github.com/LedgerHQ/orakolo