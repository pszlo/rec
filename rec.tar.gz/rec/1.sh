python btcrecover.py --tokenlist btcrecover-tokens-auto.txt --wallet wallet.dat --enable-gpu --no-eta --no-dupchecks --dsw --enable-opencl
 